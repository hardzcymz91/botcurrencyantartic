module.exports = {
    token: "Nzk1MTQ3MDEzODM0MTQ1ODEy.X_FIXQ.znsz8kt3uzCAqjqvgPuUf-L2328",
    prefix: "a?",
    admins: [
        "795605552545136652"
],
    debug: true,
    countChannel: "countChannelID"
};
